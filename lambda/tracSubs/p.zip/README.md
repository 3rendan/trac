# fxnction must

1. Create row in the trac-subs DynamoDb
   1. Questions:
      1. Should it POST straight to Notes?
         1. Get info on endpoints from beta
   2. Row MUST include: programId, subscriber name, company, position, phone, email, subscription duration, subscription beginning date, token from Square